/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queues;
//import static java.lang.Character.isDigit;
import static java.lang.Character.isDigit;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
//import java.lang.NullPointerException;
public class Queues<T> {
//shows which goes first in pemdas char c is the symbol
    static int precedence(char c){
        switch(c){
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
        }
        return -1;
    }
    static int precedences(String c){
        switch(c){
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case "^":
                return 3;
        }
        return -1;
    }
    static Queue<Character> backin(Queue<Character> q,char c){
        Queue<Character> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
    static Queue<String> backins(Queue<String> q,String c){
        Queue<String> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
    static Queue<Integer> backini(Queue<Integer> q,int c){
        Queue<Integer> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
    static Queue<Character> flip(Queue<Character> nums){
        Queue<Character> nums2;
        nums2 = new LinkedList<>();
        String s=" ";
        for(int x= nums.size(); x>0;x--){
            s+=nums.remove();
        }
        char ch;
        int a;
        String r="";
        for(int x= s.length()-1;x>0;x--){
            ch=s.charAt(x);
            nums2.add(ch);
        }
    return nums2;
    }
    static Queue<String> flips(Queue<String> nums){
        Queue<String> nums2;
        nums2 = new LinkedList<>();
        Queue<String> nums3;
        nums3 = new LinkedList<>();
        String s=" ";
        int xa=nums.size()-1;
        for(int x= nums.size(); x>0;x--){
            for(int i= nums.size()-1; i>0;i--){
                nums2.add(nums.remove());
            for(int i1=nums2.size()-(nums2.size()+1); i1>0;i1--){
                nums.add(nums2.remove());
            }
            }
            nums3.add(nums.remove());
            nums=nums2;
        }
    return nums3;
    }
    static Queue<Character> backup(String s){
        Queue<Character> n;
        n = new LinkedList<>();
        Queue<Character> nums;
        nums = new LinkedList<>();
     char ch;
        for(int x= s.length()-1;x>=0;x--){
            ch=s.charAt(x);
            nums.add(ch);
  //                  System.out.println("backup "+nums);

        }
        nums=flip(nums);
//                            System.out.println("backup "+nums);
/*
        char f;
        int i=nums.size()-2;
        for(int x=0;x<=nums.size()+1;x++){
            if(x!=i){
                n.add(nums.remove());
            }
            else{
               f=nums.remove();
               n.add(nums.remove());
               n.add(f);
            }
        }
                    System.out.println("backup "+n);
  */
                            return nums;
    }
    int top_int=-1;
static String convert(String expression){
        String s="";
        char ca=' ';
        int x1=0;
        int x2=0;
        String result ="";
        Queue<Character> stack = new LinkedList<>();
        Queue<Character> stack2 = new LinkedList<>();
        for(int i =0; i<expression.length();i++){//goes on until there is nothing left to be taken from the expression
            char c= expression.charAt(i);//c is the char at i coming from left to right
            s="";
            if(precedence(c)>0){//when c is +-* / or ^
                stack=flip(stack);
                while(stack.isEmpty()==false && precedence(stack.peek())>=precedence(c)){//when the precedence of the next number is more than the current
                    if(ca=='^'&&precedence(stack.peek())==3){
                        stack2=backup(result);
                        result="";
                        for(int x=stack2.size();x>0;x--){
                            result+=stack2.remove();
                        }
                        x1=1;
                    }
                    int x3=0;
                    if(x1==0){
                    ca=stack.remove();
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                    }
                    else{
                        ca=expression.charAt(i+1);
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                    result +=stack.remove();//if above is the same than it removes c from the stack and puts it in result
                        x1=0;
                        x2=1;
                        x3=1;
                    }
                    stack=flip(stack);
                }
                stack.add(c);
            }
            else{//result has number put at end
                if(x2==0){
                result+=c;
                }
                else{
                x2=0;
            }
            }
        }
        for(int i = stack.size(); i>0;i--){
            s +=stack.remove();
        }
        char ch;//c is the char at i coming from left to right
        for(int i =s.length()-1; i>=0;i--){//goes on until there is nothing left to be taken from the expression
            ch=s.charAt(i);
            result+=ch;
        }
        return result;
    }
//starts with stack may need to redo entire evaluate part
    static int evaluateq(Queue<Character> Stack2){//pointer
        Queue<Integer> intStack = new LinkedList<>();//
        Queue<String> sintStack = new LinkedList<>();//
        Queue<Integer> intorsymbol = new LinkedList<>();//1for int 2 for symbol
        Queue<Character> symbol = new LinkedList<>();//
        char ch;
        int i =0,operand1,operand2;
        char op;
        int f=0;
        int operand=0;
        Stack2=flip(Stack2);
        char op2;
        String fg = "";
        int sss=Stack2.size();
        while(sss>2){//goes until stack2 is empty
            //puts numbers and symbols into seperate queues to be merged back into stack2 later
            ch = Stack2.poll();
            if(Stack2.isEmpty()==false){
                op=Stack2.poll();
            }
            else{
                op=' ';
            }
            if(Stack2.isEmpty()==false){
                op2=Stack2.poll();
            }            
            else{
                op2=' ';
            }
            Stack2=backin(Stack2,op2);
            Stack2=backin(Stack2,op);
//            System.out.println(Stack2+" back");
            if(isDigit(ch)){
                intStack.add(ch-'0');
                intorsymbol.add(1);
            }
            else if((isDigit(op))&&(isDigit(op2))){
//                System.out.println(intStack+"hi");
                intStack.add(op-'0');
                intStack.add(op2-'0');
//                System.out.println(intStack+"hi");
                Stack2.poll();
                Stack2.poll();
//                symbol=flip(symbol);
//                ch=symbol.peek();
//                symbol=flip(symbol);
                sintStack=queuetostringq(intStack);
                sintStack=flips(sintStack);
                intStack=stringtoint(sintStack);
//                System.out.println(intStack);
                operand2=intStack.poll();
                operand1=intStack.poll();
//                System.out.println(intStack);
                intorsymbol.add(1);
//                System.out.println("ch "+ch);
                switch(ch){
                    case '+':
                        intStack.add(operand1+operand2);
                        operand=operand1+operand2;
                        break;
                    case '-':
                        intStack.add(operand1-operand2);
                        operand=operand1-operand2;
                        break;
                    case '*':
                        intStack.add(operand1*operand2);
//                        System.out.println(operand1+" * "+operand2);
                        break;
                    case '/':
                        if(operand2!=0){
                            intStack.add(operand1/operand2);
                            operand=operand1/operand2;
                        }
                        else if(operand2==0){
                            intStack.add(0);
                            operand=0;
                        }
                        break;
                    case '^':
                        intStack.add((int) Math.pow(operand1, operand2));
//                        System.out.println(operand1+" ^ "+operand2);
                }
//                              System.out.println(intStack);
//    System.out.println();
                sintStack=queuetostringq(intStack);
                sintStack=flips(sintStack);
                intStack=stringtoint(sintStack);
//                System.out.println(intStack);
            }
            else{
                fg+=ch;
                symbol.add(ch);
                intorsymbol.add(2);
            }
            sss=Stack2.size();
        }
        while(Stack2.isEmpty()==false){
            ch = Stack2.poll();
            if(isDigit(ch)){
                intStack.add(ch-'0');
                intorsymbol.add(1);
            }
            else{
                fg+=ch;
                symbol.add(ch);
                intorsymbol.add(2);
            }
        }
//            System.out.println(intStack);
//            System.out.println("part2");
        Queue<String> str = new LinkedList<>();//
        Queue<String> ssymbol = new LinkedList<>();//
        sintStack=queuetostringq(intStack);
        ssymbol=charqueuetostringq(symbol);
        int ssy=ssymbol.size();
        while(ssy!=0){
        //now that all of them are put in a string queue
        //use int or symbol(which may not need to be a string) 
        //to determine the order that things are placed into str 
        // use a for loop for int or symbol
        //if the result of int intorsymbol is 1 it is int stack
        //if the result of int intorsymbol is 2 it is symbol
        //when str is filled check if the string is + - * / or ^ 
        //if it is and needs to be operated convert numbers back with another class 
            int ios=0;
            for(int x=intorsymbol.size();x>0;x--){//merges intstack and symbol back into stack2
                ios=intorsymbol.remove();
                if(ios==1){
                    str.add(sintStack.remove());
                //make intstack into string string along with other stacks using above lines as guidence
                //when adding opperands use a differant stack that is regularly converted back to a string stack using another class
                //have second while loop under to be able to read numbers like 24 by checking if string value equals + - * / or ^
                //if string value isn't one of those it is a number
            }
            else if(ios==2){
                str.add(ssymbol.remove());
            }
        }
            sss=str.size();
String det="";//ch
String opp="";
String opp2="";
String soperand="";
String soperand1="";
String soperand2="";
        while(sss>2){//goes until stack2 is empty
            det = str.poll();
//            System.out.println(sintStack);
            if(str.isEmpty()==false){
            opp=str.poll();
            }
            else{
                opp="";
            }
            if(str.isEmpty()==false){
                opp2=str.poll();
            }            
            else{
                opp2="";
            }
            str=backins(str,opp2);
            str=backins(str,opp);
            if(precedences(det)==-1){
//                System.out.println("if");
                sintStack.add(det);
                intorsymbol.add(1);
            }
            else if((precedences(opp)==-1)&&(precedences(opp2)==-1)){
//        System.out.println("else if");
                sintStack.add(opp);
                sintStack.add(opp2);
                str.poll();
                str.poll();
                sintStack=flips(sintStack);
                intStack=stringtoint(sintStack);
                operand2=intStack.poll();
                operand1=intStack.poll();
                intorsymbol.add(1);
              switch(det){
                    case "+":
                        intStack.add(operand1+operand2);
//    System.out.println(operand1+"+"+operand2);
                        sintStack=queuetostringq(intStack);
                        break;
                    case "-":
                        intStack.add(operand1-operand2);
//    System.out.println(operand1+"-"+operand2);
                        sintStack=queuetostringq(intStack);
                        break;
                    case "*":
                 intStack.add(operand1*operand2);
//    System.out.println(operand1+"*"+operand2);
              sintStack=queuetostringq(intStack);
                        break;
                    case "/":
                        if(operand2!=0){
                            intStack.add(operand1/operand2);
//    System.out.println(operand1+"/"+operand2);
              sintStack=queuetostringq(intStack);
                        }
                        else if(operand2==0){
                            intStack.add(0);
//                                System.out.println("zero");
  //  System.out.println(operand1+"/"+operand2);
              sintStack=queuetostringq(intStack);
                        }
                        break;
                    case "^":
//    System.out.println(operand1+"^"+operand2);
                        intStack.add((int) Math.pow(operand1, operand2));
                        sintStack=queuetostringq(intStack);
                }
            }
            else{
          //      System.out.println("else");
                fg+=det;
                ssymbol.add(det);
                intorsymbol.add(2);
            }
            sss=str.size();
        }
        while(str.isEmpty()==false){
            det = str.poll();
            if(precedences(det)==-1){
                sintStack.add(det);
                intorsymbol.add(1);
            }
            else{
            fg+=det;
                ssymbol.add(det);
                intorsymbol.add(2);
            }
        }
ssy=ssymbol.size();
//System.out.println("done");
  //      System.out.println(sintStack);
    //    System.out.println(ssymbol);
        }
        intStack=stringtoint(sintStack);
//            System.out.println(ssymbol);
//            System.out.println(str);
//        System.out.println(intStack);
  //      System.out.println();
                return intStack.peek();

    }
    static String posswitch(int i){
        String s="";
                switch(i){
                    case 1:
                        s="1";
                        break;
                    case 2:
                        s="2";
                        break;
                    case 3:
                        s="3";
                        break;
                    case 4:
                        s="4";
                        break;
                    case 5:
                        s="5";
                        break;
                    case 6:
                        s="6";
                        break;
                    case 7:
                        s="7";
                        break;
                    case 8:
                        s="8";
                        break;
                    case 9:
                        s="9";
                        break;
                    case 0:
                        s="0";
                        break;
        
    }
                return s;
    }
    static int charswitch(char i){
        int s=0;
                switch(i){
                    case '1':
                        s=1;
                        break;
                    case '2':
                        s=2;
                        break;
                    case '3':
                        s=3;
                        break;
                    case '4':
                        s=4;
                        break;
                    case '5':
                        s=5;
                        break;
                    case '6':
                        s=6;
                        break;
                    case '7':
                        s=7;
                        break;
                    case '8':
                        s=8;
                        break;
                    case '9':
                        s=9;
                        break;
                    case '0':
                        s=0;
                        break;
        
    }
                return s;
    }
    static Queue<String> charqueuetostringq(Queue<Character> symbol){
        Queue<String> str = new LinkedList<>();//
        String s="";
        int i;
        for(int x=symbol.size();x>0;x--){//merges intstack and symbol back into stack2
            i=symbol.remove();
            switch(i){
                    case '+':
                        s="+";
                        str.add(s);
                        break;
                    case '-':
                        s="-";
                        str.add(s);
                        break;
                    case '*':
                        s="*";
                        str.add(s);
                        break;
                    case '/':
                        s="/";
                        str.add(s);
                        break;
                    case '^':
                        s="^";
                        str.add(s);
                        break;
            }
        }
        return str;
    }        
    static Queue<String> queuetostringq(Queue<Integer> intstack){
        //System.out.println(intstack);
        Queue<String> str = new LinkedList<>();//
        String s="";
        int i;
        int g;
        char ch;
        for(int x=intstack.size();x>0;x--){//merges intstack and symbol back into stack2
            i=intstack.remove();
            g=i;
//            System.out.println(i);

            if(i>=0){
                s="";
                    //System.out.println(i);
                while(g>=10)
                {
             //       System.out.println(i);
                i=g;
                i=i%10;
                s=posswitch(i)+s;
                //System.out.println(s);
                  //  System.out.println(posswitch(i));
                g=g-i;
                g=g/10;
                }
                i=g;
                i=i%10;
                s=posswitch(i)+s;
                //System.out.println(s);
                  //  System.out.println(posswitch(i));
                g=g-i;
                g=g/10;
        
            }else if(i<0){
                g=i*-1;
                s="";
//                    System.out.println(i);
                while(g>=10)
                {
             //       System.out.println(i);
                i=g;
                i=i%10;
                s=posswitch(i)+s;
                //System.out.println(s);
                  //  System.out.println(posswitch(i));
                g=g-i;
                g=g/10;
                }
                i=g;
                i=i%10;
                s=posswitch(i)+s;
          //              System.out.println(s);
                s="-"+s;
            //            System.out.println(s);
                //    System.out.println(posswitch(i));
                g=g-i;
                g=g/10;
        
            }
            str.add(s);
        }
          //  System.out.println(str);
            //System.out.println();
            return str;
    }
    static Queue<Integer> stringtoint(Queue<String> str){
    Queue<Integer> nums2;
        nums2 = new LinkedList<>();
        String s=" ";
        char ch;
        int ad=0;
        int place;
        int power;
        int intch;
        int i2;
        for(int x= str.size(); x>0;x--){
            s=str.remove();
  //          System.out.println(s+" string");
            i2=s.length()-1;
            ad=0;
            
            for(int i=0;i<s.length();i++){
                //use i as a way to keep track of what place one tens etc
                ch=s.charAt(i);
                intch=charswitch(ch);
    //            System.out.println(intch);
//                System.out.println(ch+"hcchchchchchc");
                //may need to flip string if it reads the wrong way
//                if(isDigit(ch)){
                    power=((int) Math.pow(10, i2));
                    //System.out.println(power);
                    //System.out.println(ch);
                    place=intch*power;
                    //System.out.println(place+"asdfghjkl");
                    
                    ad=place+ad;
                    //System.out.println(ad);
                    
  //              }
                    i2--;
            }
            nums2.add(ad);
        }
    return nums2;
        
    }
//change to string to queue
    static Queue<Character> stringtoqueue(String expression){
        Queue<Character> stack = new LinkedList<>();
        for(int i =0; i<expression.length();i++){
            char c= expression.charAt(i);
            stack.add(c);
        }
        return stack;
    }
    //should be good now as all are numbers and won't make a difference on order
    static Queues<Integer> ran(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
        Queues<Integer> st=new Queues();
        number=num.nextInt(10);
        //System.out.println(number);
        st.enqueue(number);
        for(int i=2;i<top;i++){
                number=num.nextInt(10);
        //System.out.println(number);
                st.enqueue(number);
        }
        number=num.nextInt(10);
        //System.out.println(number);
        st.enqueue(number);
        //System.out.println("done");
        return st;
    }
    //change stack to queue
    static Queues<Integer> rans(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
        Queues<Integer> st=new Queues();
        number=num.nextInt(5);//put at 6 instead of 7 to close parenthesis
      //  System.out.println(number);
        st.enqueue(number);
        for(int i=2;i<top;i++){
                number=num.nextInt(5);
                st.enqueue(number);
    //    System.out.println(number);
        }
        number=num.nextInt(5);
  //      System.out.println(number);
        st.enqueue(number);
        //System.out.println("done");
        return st;
    }
    //uses stacks may have bto change it but may be able to just change stack into queue
    static String inttostr(Queues<Integer> st,Queues<Integer> st2,int top,int tops){//needs to have one more number than symbol
        String s="";
        int t=top+tops;
        int n=0;
        int x=0;
        for(int i = 0; i<t;i++){
           if((i%2)==0){//checks if i is even when it is put a number
               x= st.dequeue();
               switch(x){
                   case 0:
                       s=s+"0";
                       break;
                   case 1:
                       s=s+"1";
                       break;
                   case 2:
                       s=s+"2";
                       break;
                   case 3:
                       s=s+"3";
                       break;
                   case 4:
                       s=s+"4";
                       break;
                   case 5:
                       s=s+"5";
                       break;
                   case 6:
                       s=s+"6";
                       break;
                   case 7:
                       s=s+"7";
                       break;
                   case 8:
                       s=s+"8";
                       break;
                   case 9:
                       s=s+"9";
                       break;
               }
           }
           else if((i%2)!=0){
               x= st2.dequeue();
               switch(x){
                   case 0:
                       s=s+"+";
                       break;
                   case 1:
                       s=s+"-";
                       break;
                   case 2:
                       s=s+"*";
                       break;
                   case 3:
                       s=s+"/";
                       break;
                   case 4:
                       s=s+"^";
                       break;
                   case 5:
                       if(n==0){
                           s=s+"(";
                           n=1;
                       }
                       else if(n==1){
                           s=s+")";
                           n=0;
                       }
                       break;
               }
           }
        }
        if(n==1)
            s=s+")";
        return s;
    }
    private final Queue<Integer> list;
    public Queues(){
        Queue<Integer> q =new LinkedList<Integer>();
        list=q;
    }
    public boolean isEmpty(){
        return(list.size()==0);
    }
    public void enqueue(int item){
        list.add(item);
    }
    int it =0;
    //try to get this to be int in a differant way
    public int dequeue(){
        int item= list.remove();
        it=it+1;
        return item;
    }
    public int peek(){
        return list.peek();
    }
    public static void main(String[] args) {
        String in = "";
        int top=5;
        int tops=4;
        in=inttostr(ran(top),rans(tops),top,tops);
        //in="3+7/8-6-3";//for whatever reason it takes out a five and +
        String post = convert(in);
        Queue<Character> n;
        n = new LinkedList<>();
        n=stringtoqueue(post);
        System.out.println("Infix Expression: "+in);
        System.out.println("Postfix Expression: "+post);
        System.out.println("Result is: "+ evaluateq(n));//stackp goes in forward
  }
}
/*
        String s="";
        char ca=' ';
        int x1=0;
        int x2=0;
        String result ="";
        Queue<Character> stack = new LinkedList<>();
        Queue<Character> stack2 = new LinkedList<>();
        for(int i =0; i<expression.length();i++){//goes on until there is nothing left to be taken from the expression
            char c= expression.charAt(i);//c is the char at i coming from left to right
            s="";
            System.out.println("next char is "+c);
                System.out.println("result: "+result);
            if(precedence(c)>0){//when c is +-* / or ^
                stack=flip(stack);
                System.out.println("if");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("s: "+s);
                System.out.println();
                while(stack.isEmpty()==false && precedence(stack.peek())>=precedence(c)){//when the precedence of the next number is more than the current
                System.out.println("while");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("s: "+s);
                System.out.println();
                    //c is the symbol that occurs later in string
                    //result +=c;//if above is the same than it removes c from the stack and puts it in result
                    //stack=flip(stack);
                
                    if(ca=='^'&&precedence(stack.peek())==3){
                                        System.out.println("if2");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("ca: "+ca);
                System.out.println("s: "+s);
                System.out.println();

                        stack2=backup(result);
                    //    System.out.println(stack2);
                        result="";
                        for(int x=stack2.size();x>0;x--){
                System.out.println("for");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("s: "+s);
                System.out.println();
                            result+=stack2.remove();
                        }
                        //result+=expression.charAt(i+1);
                        x1=1;
                        System.out.println(result+" "+expression.charAt(i+1)+"           "+expression);
                    }
                    int x3=0;
                    if(x1==0){
                    ca=stack.remove();
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                        
                    }
                    else{
                        ca=expression.charAt(i+1);
//                        System.out.println("remove: "+stack.remove());
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                    result +=stack.remove();//if above is the same than it removes c from the stack and puts it in result
                        
                        x1=0;
                        x2=1;
                        x3=1;
                    }
                  //  System.out.println("symbol "+ca);
                //    System.out.println("peek "+stack.peek());
//                    if(x3==0){
  //                  result +=ca;//if above is the same than it removes c from the stack and puts it in result
    //                }
//ca=expression.charAt(i+1);
                    stack=flip(stack);
              //      System.out.println("symbol result "+ result + " stack "+ stack);
                }
                
                stack.add(c);
          //      System.out.println("end"+stack);
            }
            else{//result has number put at end
                if(x2==0){
                result+=c;
                }
                else{
                x2=0;
            }
        //        System.out.println("number result "+ result + " stack "+ stack);
                System.out.println(c+"else");
            }
        }
  //      System.out.println("remaining " + stack2);
        for(int i = stack.size(); i>0;i--){
            s +=stack.remove();
//            System.out.println(s);
        }
  //      System.out.println(s.length());
//        System.out.println(s.charAt(1));
        char ch;//c is the char at i coming from left to right
            //expression.charAt(i);
        for(int i =s.length()-1; i>=0;i--){//goes on until there is nothing left to be taken from the expression
    //        System.out.println(result);
            ch=s.charAt(i);
            result+=ch;
        }
        return result;
    }

*/
//uses stacks convers string expression to string result or infix to postfix
/*
    static int evaluate(Stack<Character> postfix){//pointer
        Stack<Integer> intStack = new Stack<>();//
        Stack<Character> Stack2 = new Stack<>();//
        char ch= postfix.peek();
    int i =0,operand1,operand2;
        char op;
        while(postfix.empty()==false){//only stops when ppostfix is empty
            ch = postfix.pop();
            if(isDigit(ch)){//puts ch into stackk2 and leaves it at that
                Stack2.push(ch);
            }
            else{//when ch is a symbol op is set to be the number before it
                op=postfix.peek();
                Stack2.push(ch);
            }
        }
        while(Stack2.empty()==false){//goes until stack2 is empty
            ch = Stack2.pop();
            if(isDigit(ch)){
                intStack.push(ch-'0');
            }
            else{
                operand2=intStack.pop();
                operand1=intStack.pop();
                switch(ch){
                    case '+':
                        intStack.push(operand1+operand2);
                        break;
                    case '-':
                        intStack.push(operand1-operand2);
                        break;
                    case '*':
                        intStack.push(operand1*operand2);
                        break;
                    case '/':
                        if(operand2!=0){
                            intStack.push(operand1/operand2);
                        }
                        else if(operand2==0){
                            intStack.push(0);
                        }
                        break;
                    case '^':
                        intStack.push((int) Math.pow(operand1, operand2));
                }
            }
        }
                return intStack.peek();
    }
/*    static String convert(String expression){
        String s="";
        char ca=' ';
        String result ="";
        Queue<Character> stack = new LinkedList<>();
        Queue<Character> stack2 = new LinkedList<>();
        int skip=0;
        char c=' ';
        System.out.println(expression);

        for(int i =0; i<expression.length();i++){//goes on until there is nothing left to be taken from the expression
            if(skip==0){
            c= expression.charAt(i);//c is the char at i coming from left to right
            System.out.println(result);
            System.out.println("not skip "+c);
            }
            else if(skip==1){
                //stack.remove();
                                System.out.println(result);
                                System.out.println("skip "+c);
                c=' ';
                skip=0;
            }
            s="";
  //          System.out.println(c+"c");
            if(c==' ')
            {
            ///    System.out.println("skip");
            }
            else if(precedence(c)>0){//when c is +-* / or ^
                                stack=flip(stack);
                System.out.println(result);
                System.out.println(stack);
                System.out.println(stack2);
System.out.println();
int d=0;
                while(stack.isEmpty()==false && precedence(stack.peek())>=precedence(c)&&d==0){//when the precedence of the next number is more than the current
                System.out.println("result "+result);
             //       System.out.println("result2 " +result);
                //c is the symbol that occurs later in string
      //              System.out.println("resulc2 " +ca+" "+stack.peek());
                    if(ca=='^'&&precedence(stack.peek())==3){
   //     System.out.println(stack2);
                    System.out.println("result2 " +result);
                        stack2=backup(result);
        //System.out.println(stack);
        System.out.println(stack2);
                        result="";
                        for(int x=stack2.size();x>0;x--){
            //                                    System.out.println("re eeeee" +stack2);
                            result+=stack2.remove();
     //   System.out.println("for" +result);
                        }
                        //implement number before sign here
         //               System.out.println("exp "+expression+" "+i);
                        result+=expression.charAt(i+1);
                        System.out.println("hi"+expression.charAt(i+1)+" "+result);
                        skip=1;
                        
                        
                        
                        
                        //need ^6^+ to be ^^+6+ 
                        
                        
                        
                        
                        
                        
                    }
                    System.out.println(stack);
                    ca=stack.remove();
                                       System.out.println("asdfghjk " +result+" "+ca);

                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                                       System.out.println("asdfghjk " +result);
                    stack=flip(stack);
                }
                stack.add(c);
                System.out.println("reeeeeeeeeeesult "+result);
                
            }
            else{//result has number put at end
                result+=c;
                System.out.println("c"+c);
            }
                        System.out.println("            "+result);

        }
           //     System.out.println(stack);
        for(int i = stack.size(); i>0;i--){
            s +=stack.remove();
        }
                System.out.println(s.length()+"s"+s);
        char ch;//c is the char at i coming from left to right
    //    for(int i =s.length()-1; i>=0;i--){//goes on until there is nothing left to be taken from the expression
      //      ch=s.charAt(i);
        //    result+=ch;
        //}
        return result;
    }
*/
